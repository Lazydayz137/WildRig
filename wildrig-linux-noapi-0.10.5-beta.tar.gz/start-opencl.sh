#!/bin/bash
while true
do
./wildrig --opencl-launch=256x0 --send-stale --url=bbr.luckypool.io:5577 --user=WALLET --pass=IFNEEDED --scratchpad-file=scratchpad.bin --scratchpad-url=http://eu-bbr.luckypool.io/scratchpad.bin
sleep 5
done
